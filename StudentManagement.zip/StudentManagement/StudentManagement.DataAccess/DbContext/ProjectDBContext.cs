﻿using Microsoft.EntityFrameworkCore;
using StudentManagement.DataAccess.Entities;

namespace StudentManagement.DataAccess.DbContext2
{
    public class ProjectDBContext : DbContext
    {
        public ProjectDBContext()
        {
        }

        public ProjectDBContext(DbContextOptions<ProjectDBContext> options) : base(options)
        {

        }

        public DbSet<Student> Student { get; set; }
        public DbSet<Standard> Standard { get; set; }
        public DbSet<Employee> Employees { get; set; }
        public DbSet<Department> Departments { get; set; }

        //protected override void OnModelCreating(ModelBuilder modelBuilder)
        //{
        //    modelBuilder.Entity<Student>().HasData(
        //        new Student()
        //        {
        //            StudentId = 1,
        //            FirstName = "vraj",
        //            LastName = "shah",
        //            Email = "v@gmail.com",
        //            Course = "Maths"
        //        });
        //}
    }
}
