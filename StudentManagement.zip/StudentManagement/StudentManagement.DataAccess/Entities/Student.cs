﻿using StudentManagement.DataAccess.Entities;
using System.ComponentModel.DataAnnotations.Schema;

namespace StudentManagement.DataAccess.Entities
{
    public class Student
    {
        /// <summary>
        /// Gets or sets the student identifier.
        /// </summary>
        /// <value>
        /// The student identifier.
        /// </value>
        public int StudentId { get; set; }
        /// <summary>
        /// Gets or sets the first name of the student.
        /// </summary>
        /// <value>
        /// The first name of the student.
        /// </value>
        public string? FirstName { get; set; }
        /// <summary>
        /// Gets or sets the last name of the student.
        /// </summary>
        /// <value>
        /// The last name of the student.
        /// </value>
        public string? LastName { get; set; }
        /// <summary>
        /// Gets or sets the email.
        /// </summary>
        /// <value>
        /// The email.
        /// </value>
        public string? Email { get; set; }
        /// <summary>
        /// Gets or sets the Course.
        /// </summary>
        /// <value>
        /// The Course.
        /// </value>
        public string? Course { get; set; }
        /// <summary>
        /// Gets or sets the CreatedOn.
        /// </summary>
        /// <value>
        /// The CreatedOn.
        /// </value>
        public DateTime? CreatedOn { get; set; }
        /// <summary>
        /// Gets or sets the UpdatedOn.
        /// </summary>
        /// <value>
        /// The UpdatedOn.
        /// </value>
        public DateTime? UpdatedOn { get; set; }

        //Foreign key for Standard
        public int StandardId { get; set; }
        public Standard Standard { get; set; }
    }
}