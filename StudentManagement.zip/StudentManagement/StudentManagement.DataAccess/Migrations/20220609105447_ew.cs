﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace StudentManagement.DataAccess.Migrations
{
    public partial class ew : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Employees_Departments_departmentId1",
                table: "Employees");

            migrationBuilder.RenameColumn(
                name: "departmentId1",
                table: "Employees",
                newName: "departmentId");

            migrationBuilder.RenameIndex(
                name: "IX_Employees_departmentId1",
                table: "Employees",
                newName: "IX_Employees_departmentId");

            migrationBuilder.AddForeignKey(
                name: "FK_Employees_Departments_departmentId",
                table: "Employees",
                column: "departmentId",
                principalTable: "Departments",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Employees_Departments_departmentId",
                table: "Employees");

            migrationBuilder.RenameColumn(
                name: "departmentId",
                table: "Employees",
                newName: "departmentId1");

            migrationBuilder.RenameIndex(
                name: "IX_Employees_departmentId",
                table: "Employees",
                newName: "IX_Employees_departmentId1");

            migrationBuilder.AddForeignKey(
                name: "FK_Employees_Departments_departmentId1",
                table: "Employees",
                column: "departmentId1",
                principalTable: "Departments",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
