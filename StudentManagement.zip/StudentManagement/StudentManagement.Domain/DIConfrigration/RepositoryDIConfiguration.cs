﻿using Microsoft.Extensions.DependencyInjection;
using StudentManagement.Infrastructure;
using StudentManagement.Service;

namespace StudentManagement.Domain.DIConfrigration
{
    public static  class RepositoryDIConfiguration
    {
        public static void ConfigureRepositoryDI(this IServiceCollection services)
        {
            services.AddScoped<IStudentService, StudentService>();
            services.AddScoped<IEmployeeService, EmployeeService>();
        }
    }
}