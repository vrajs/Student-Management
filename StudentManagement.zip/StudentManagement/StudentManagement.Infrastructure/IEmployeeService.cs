﻿using StudentManagement.Model;
using System.Collections.Generic;

namespace StudentManagement.Infrastructure
{
    public interface IEmployeeService
    {
        
        Task<List<EmployeeDto>> GetEmployees();
        List<EmployeeDto> GetDepartmentsWithEmployees();
        Task<List<DepartmentDto>> GetDepartments();
        Task<EmployeeDto> GetEmployeeById(int? id);

        Task<int> AddEmployee(EmployeeDto student);

        Task<int> DeleteEmployee(int? id);

        Task<int> UpdateEmployee(EmployeeDto student);
        bool SendMail(Email email);
        
    }
}