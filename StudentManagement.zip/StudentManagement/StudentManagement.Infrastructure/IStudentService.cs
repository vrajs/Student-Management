﻿using StudentManagement.Model;

namespace StudentManagement.Infrastructure
{
    public interface IStudentService
    {
        Task<List<StudentDto>> GetStudents();
        Task<List<StudentDto>> GetStudentsByFilter(string? firstname, string? lastname, string? course);

        Task<StudentDto> GetStudentById(int? id);

        Task<int> AddStudent(StudentDto student);

        Task<int> DeleteStudent(int? id);

        Task<int> UpdateStudent(StudentDto student);

        
    }
}