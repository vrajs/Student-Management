﻿namespace StudentManagement.Model
{
    public class EmployeeDto
    {
        public int Id { get; set; }
        public string Firstname { get; set; }
        public string LastName { get; set; }
        public string Gender { get; set; }
        public int Salary { get; set; }
        public List<byte> Photo { get; set; } = new List<byte>();
        public bool? Wfh { get; set; }
        //public DepartmentDto department { get; set; }
        public int departmentId { get; set; }
        public string? Name { get; set; }
        public string? Location { get; set; }
    }
}