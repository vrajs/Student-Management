﻿using Microsoft.EntityFrameworkCore;
using StudentManagement.DataAccess.Entities;
using StudentManagement.DataAccess.DbContext2;
using StudentManagement.Infrastructure;
using StudentManagement.Model;
using System.Net.Mail;
using System.Text;

namespace StudentManagement.Service
{
    public class EmployeeService : IEmployeeService
    {
        #region Variable Declaration
        private readonly ProjectDBContext _projectDBContext;
        #endregion

        #region Constructor

        public EmployeeService(ProjectDBContext projectDBContext)
        {
            _projectDBContext = projectDBContext;
        }

        #endregion


        #region End points

        public async Task<List<EmployeeDto>> GetEmployees()
        {
            var employees = (from de in _projectDBContext.Departments
                             join em in _projectDBContext.Employees
                             on de.Id equals em.departmentId
                             select new EmployeeDto
                             {
                                 Id = em.Id,
                                 Firstname = em.Firstname,
                                 Name = de.Name,
                                 departmentId = de.Id,
                                 Location = de.Location,
                                 LastName = em.LastName,
                                 Gender = em.Gender,
                                 Salary = em.Salary
                             }).ToListAsync();

            return await employees;
        }
        public List<EmployeeDto> GetDepartmentsWithEmployees()
        {
            var departments = (from de in _projectDBContext.Departments
                               select new EmployeeDto
                               {
                                   Id = de.Id,
                                   Name = de.Name,
                                   Location = de.Location
                               }).ToList();

            var employees = (from em in _projectDBContext.Employees
                             select new EmployeeDto
                             {
                                 Id = em.Id,
                                 Firstname = em.Firstname,
                                 LastName = em.LastName,
                                 Gender = em.Gender,
                                 Salary = em.Salary,
                                 departmentId = em.departmentId
                             }).ToList();

            departments.AddRange(employees);

            var departmentsWithEmployees = departments.OrderBy(i => i.Id).ToList();

            return departmentsWithEmployees;
        }

        public async Task<List<DepartmentDto>> GetDepartments()
        {
            var departments = (from de in _projectDBContext.Departments
                               select new DepartmentDto
                               {
                                   Id = de.Id,
                                   Name = de.Name,
                                   Location = de.Location
                               }).ToListAsync();
            return await departments;
        }

        public async Task<int> DeleteEmployee(int? id)
        {
            int result = 0;

            if (_projectDBContext != null)
            {
                var employee = await _projectDBContext.Employees.FirstOrDefaultAsync(x => x.Id == id);

                if (employee != null)
                {
                    _projectDBContext.Employees.Remove(employee);

                    result = await _projectDBContext.SaveChangesAsync();
                }
                return result;
            }

            return result;
        }
        public async Task<EmployeeDto> GetEmployeeById(int? id)
        {
            EmployeeDto employeeDto = new EmployeeDto();
            if (_projectDBContext != null && id != null && id != 0)
            {
                return await (from de in _projectDBContext.Departments
                              join em in _projectDBContext.Employees
                              on de.Id equals em.departmentId
                              where em.Id == id
                              select new EmployeeDto
                              {
                                  Id = em.Id,
                                  Firstname = em.Firstname,
                                  Name = de.Name,
                                  departmentId = em.departmentId,
                                  Location = de.Location,
                                  LastName = em.LastName,
                                  Gender = em.Gender,
                                  Salary = em.Salary
                              }).FirstOrDefaultAsync();
            }
            return employeeDto;
        }

        public async Task<int> AddEmployee(EmployeeDto employee)
        {
            if (_projectDBContext != null)
            {
                var existingemployee = (from db in _projectDBContext.Employees
                                        where db.Id == employee.Id
                                        select db).FirstOrDefault();
                if (existingemployee == null)
                {
                    try
                    {
                        var newEmployee = new Employee
                        {
                            Firstname = employee.Firstname,
                            departmentId = employee.departmentId,
                            LastName = employee.LastName,
                            Gender = employee.Gender,
                            Salary = employee.Salary,
                            Photo = employee.Photo.ToArray(),
                            Wfh = employee.Wfh
                        };

                        await _projectDBContext.Employees.AddAsync(newEmployee);

                        await _projectDBContext.SaveChangesAsync();

                        return newEmployee.Id;
                    }
                    catch (Exception e)
                    {
                        return 0;
                    }
                }
            }

            return 0;
        }

        public async Task<int> UpdateEmployee(EmployeeDto employee)
        {
            if (_projectDBContext != null)
            {
                var existingEmployee = (from db in _projectDBContext.Employees
                                        where db.Id == employee.Id
                                        select db).FirstOrDefault();
                if (existingEmployee != null)
                {
                    existingEmployee.Id = employee.Id;
                    existingEmployee.Firstname = employee.Firstname.ToLower();
                    existingEmployee.departmentId = employee.departmentId;
                    existingEmployee.LastName = employee.LastName.ToLower();
                    existingEmployee.Gender = employee.Gender;
                    existingEmployee.Salary = employee.Salary;

                    await _projectDBContext.SaveChangesAsync();
                    return employee.Id;
                }

                return 0;
            }

            return 0;
        }


        public bool SendMail(Email email)
        {
            string to = "vashah624@gmail.com"; //To address    
            string from = "vashah624@gmail.com"; //From address    
            MailMessage message = new MailMessage(from, to);

            string mailbody = "In this article you will learn how to send a email using Asp.Net & C#";
            message.Subject = "Sending Email Using Asp.Net & C#";
            message.Body = mailbody;
            message.BodyEncoding = Encoding.UTF8;
            message.IsBodyHtml = true;
            SmtpClient client = new SmtpClient("smtp.gmail.com", 587); //Gmail smtp    
            System.Net.NetworkCredential basicCredential1 = new
            System.Net.NetworkCredential("vashah624@gmail.com", "Thevs@123");
            client.EnableSsl = true;
            client.UseDefaultCredentials = false;
            client.Credentials = basicCredential1;
            try
            {
                client.Send(message);
                return true;
            }

            catch (Exception ex)
            {
                return false;
            }
        }


        #endregion
    }
}