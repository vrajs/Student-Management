﻿using Microsoft.EntityFrameworkCore;
using StudentManagement.DataAccess.Entities;
using StudentManagement.DataAccess.DbContext2;
using StudentManagement.Infrastructure;
using StudentManagement.Model;

namespace StudentManagement.Service
{
    public class StudentService : IStudentService
    {
        #region Variable Declaration
        private readonly ProjectDBContext _studentDBContext;
        #endregion

        #region Constructor

        public StudentService(ProjectDBContext studentDBContext)
        {
            _studentDBContext = studentDBContext;
        }
        #endregion


        #region End points
        public async Task<int> DeleteStudent(int? id)
        {
            int result = 0;

            if (_studentDBContext != null)
            {
                var student = await _studentDBContext.Student.FirstOrDefaultAsync(x => x.StudentId == id);

                if (student != null)
                {
                    _studentDBContext.Student.Remove(student);

                    result = await _studentDBContext.SaveChangesAsync();
                }
                return result;
            }

            return result;
        }

        public async Task<List<StudentDto>> GetStudents()
        {
            if (_studentDBContext != null)
            {
                return await (from st in _studentDBContext.Student
                              select new StudentDto
                              {
                                  StudentId = st.StudentId,
                                  FirstName = st.FirstName,
                                  LastName = st.LastName,
                                  Course = st.Course,
                                  Email = st.Email,
                              }).ToListAsync();
            }
            return new List<StudentDto>();
        }

        public async Task<StudentDto> GetStudentById(int? id)
        {
            StudentDto studentdto = new StudentDto();
            if (_studentDBContext != null && id != null && id != 0)
            {
                return await (from x in _studentDBContext.Student
                              where x.StudentId == id
                              select new StudentDto
                              {
                                  StudentId = x.StudentId,
                                  FirstName = x.FirstName,
                                  LastName = x.LastName,
                                  Course = x.Course,
                                  Email = x.Email,
                                  CreatedOn = x.CreatedOn,
                                  UpdatedOn = x.UpdatedOn
                              }).FirstOrDefaultAsync();
            }
            return studentdto;
        }
        public async Task<List<StudentDto>> GetStudentsByFilter(string? firstname, string? lastname, string? course)
        {
            StudentDto studentdto = new StudentDto();
            var data = new List<StudentDto>();
            if (_studentDBContext != null)
            {
                data = (from x in _studentDBContext.Student
                        select new StudentDto
                        {
                            StudentId = x.StudentId,
                            FirstName = x.FirstName,
                            LastName = x.LastName,
                            Course = x.Course,
                            Email = x.Email,
                            CreatedOn = x.CreatedOn,
                            UpdatedOn = x.UpdatedOn
                        }).ToList();
                if (firstname != null)
                {
                    data = data.Where(x => x.FirstName == firstname).ToList();
                }
                if (lastname != null)
                {
                    data = data.Where(x => x.LastName == lastname).ToList();
                }
                if (course != null)
                {
                    data = data.Where(x => x.Course == course).ToList();
                }
            }
            return data;
        }

        public async Task<int> AddStudent(StudentDto student)
        {
            if (_studentDBContext != null)
            {
                var existingStudent = (from db in _studentDBContext.Student
                                       where db.StudentId == student.StudentId
                                       select db).FirstOrDefault();
                if (existingStudent == null)
                {
                    try
                    {
                        student.StandardId = 1;
                        var newStudent = new Student
                        {
                            FirstName = student.FirstName.ToLower(),
                            LastName = student.LastName.ToLower(),
                            Course = student.Course.ToLower(),
                            Email = student.Email.ToLower(),
                            StandardId =student.StandardId
                        };
                        await _studentDBContext.Student.AddAsync(newStudent);

                        await _studentDBContext.SaveChangesAsync();

                        return newStudent.StudentId;
                    }
                    catch (Exception e)
                    {
                        return 0;
                    }
                }
            }

            return 0;
        }

        public async Task<int> UpdateStudent(StudentDto student)
        {
            if (_studentDBContext != null)
            {
                var existingStudent = (from db in _studentDBContext.Student
                                       where db.StudentId == student.StudentId
                                       select db).FirstOrDefault();
                if (existingStudent != null)
                {
                    existingStudent.FirstName = student.FirstName.ToLower();
                    existingStudent.LastName = student.LastName.ToLower();
                    existingStudent.Email = student.Email.ToLower();
                    existingStudent.Course = student.Course.ToLower();
                    await _studentDBContext.SaveChangesAsync();
                    return student.StudentId;
                }

                return 0;
            }

            return 0;
        }

        #endregion
    }
}