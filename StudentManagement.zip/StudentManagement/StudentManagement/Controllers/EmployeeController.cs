﻿using StudentManagement.Infrastructure;
using Microsoft.AspNetCore.Mvc;
using StudentManagement.Model;
using Microsoft.AspNetCore.Authorization;
using System.Net.Http.Headers;
using StudentManagement.Helper;

namespace StudentManagement.Controllers
{

    /// <seealso cref="Microsoft.AspNetCore.Mvc.ControllerBase" />
    [Route("api/[controller]")]
    [Authorize]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        #region Variable Declaration

        private readonly IEmployeeService _employeeService;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly ISession _session;
        #endregion

        #region Constructor

        public EmployeeController(IEmployeeService employeeService, IHttpContextAccessor httpContextAccessor)
        {
            _employeeService = employeeService;
            _httpContextAccessor = httpContextAccessor;
            _session = _httpContextAccessor.HttpContext.Session;
        }
        #endregion

        #region API End Point


        [HttpGet]
        public async Task<IActionResult> GetEmployees()
        {
            try
            {
                var employees = await _employeeService.GetEmployees();
                if (employees == null)
                {
                    return NotFound();
                }

                return Ok(employees);
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }
        [HttpPost("UploadFile"), DisableRequestSizeLimit]
        public IActionResult Upload()
        {
            try
            {
                var file = Request.Form.Files[0];
                var folderName = System.IO.Path.Combine("Resources", "Images");
                var pathToSave = System.IO.Path.Combine(Directory.GetCurrentDirectory(), folderName);
                if (file.Length > 0)
                {
                    var fileName = ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName.Trim('"');
                    var fullPath = System.IO.Path.Combine(pathToSave, fileName);
                    var dbPath = System.IO.Path.Combine(folderName, fileName);
                    using (var stream = new FileStream(fullPath, FileMode.Create))
                    {
                        file.CopyTo(stream);
                    }
                    using (System.IO.Stream st = new System.IO.StreamReader(fullPath).BaseStream)
                    {
                        Byte[] buffer = new Byte[(int)st.Length];

                        using (System.IO.MemoryStream m = new System.IO.MemoryStream())
                        {
                            while (st.Read(buffer, 0, (int)st.Length) > 0)
                            {
                                m.Write(buffer, 0, (int)st.Length);
                            }
                            buffer = m.ToArray();

                            HttpContext.Session.SetString(SessionKeys.Photo, Convert.ToBase64String(buffer));
                        }
                    }
                    return Ok(new { dbPath });
                }
                else
                {
                    return BadRequest();
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex}");
            }
        }
        [HttpGet("GetDepartmentsWithEmployees")]
        public async Task<IActionResult> GetDepartmentsWithEmployees()
        {
            try
            {
                var departmentsWithEmployees =  _employeeService.GetDepartmentsWithEmployees();
                if (departmentsWithEmployees == null)
                {
                    return NotFound();
                }

                return Ok(departmentsWithEmployees);
            }
            catch (Exception ex)
            {
                return NotFound(ex);
            }
        }
        [HttpGet("GetDepartments")]
        public async Task<IActionResult> GetDepartments()
        {
            try
            {
                var departments = await _employeeService.GetDepartments();
                if (departments == null)
                {
                    return NotFound();
                }

                return Ok(departments);
            }
            catch (Exception ex)
            {
                return NotFound(ex);
            }
        }
        [HttpGet("GetEmployeeById")]
        public async Task<IActionResult> GetEmployeeById(int? id)
        {
            if (id == null)
            {
                return BadRequest();
            }

            try
            {
                var employee = await _employeeService.GetEmployeeById(id);

                if (employee == null)
                {
                    return NotFound();
                }

                return Ok(employee);
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }


        [HttpPost]
        public async Task<IActionResult> AddEmployee(EmployeeDto employee)
        {
            employee.Photo = string.IsNullOrEmpty(HttpContext.Session.GetString("Photo")) ? new List<byte>() : Convert.FromBase64String(HttpContext.Session.GetString("Photo")).ToList();
            if (ModelState.IsValid)
            {
                try
                {
                    var employeeid = await _employeeService.AddEmployee(employee);
                    if (employeeid > 0)
                    {
                        return Ok(employeeid);
                    }

                    return NotFound();
                }
                catch (Exception ex)
                {
                    return BadRequest(ex);
                }
            }

            return BadRequest();
        }

        [HttpGet("SendMail")]
        public IActionResult SendMail()
        {
            Email email = new Email();
            email.Subject = "Added Employee";
            email.Text = "Test";
            email.To = "vashah624@gmail.com";
            if (ModelState.IsValid)
            {
                try
                {
                    var employeeid =  _employeeService.SendMail(email);

                    return Ok(true);
                }
                catch (Exception ex)
                {
                    return BadRequest(ex);
                }
            }

            return BadRequest();
        }

        [HttpDelete]
        public async Task<IActionResult> DeleteEmployee(int? id)
        {

            if (id == null)
            {
                return BadRequest();
            }

            int result = 0;
            try
            {
                result = await _employeeService.DeleteEmployee(id);
                if (result == 0)
                {
                    return NotFound();
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
            return Ok();
        }

        [HttpPut]
        public async Task<IActionResult> UpdateEmployee(EmployeeDto employee)
        {

            if (ModelState.IsValid)
            {
                try
                {
                    var employeeid = await _employeeService.UpdateEmployee(employee);

                    if (employeeid > 0)
                    {
                        return Ok(employeeid);
                    }
                    return NotFound();
                }
                catch (Exception ex)
                {
                    return BadRequest(ex);
                }
            }

            return BadRequest();
        }

        #endregion
    }
}
