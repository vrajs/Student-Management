﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using StudentManagement.Model;
using System.IdentityModel.Tokens.Jwt;
using System.Text;

namespace StudentManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        #region Variable Declaration
        private IConfiguration _config;
        #endregion

        #region Constructor
        public LoginController( IConfiguration config)
        {
            _config = config;
        }
        #endregion

        #region API EndPoints
        [HttpPost]
        public IActionResult Login([FromBody] SignInModel login)
        {
            IActionResult response = Unauthorized();
            var user = AuthenticateUser(login);

            if (user != null)
            {
                var tokenString = GenerateJSONWebToken(user);
                response = Ok(new { token = tokenString });
            }

            return response;
        }

        private string GenerateJSONWebToken(SignInModel userInfo)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Jwt:Key"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(_config["Jwt:Issuer"],
              _config["Jwt:Issuer"],
              null,
              expires: DateTime.Now.AddMinutes(120),
              signingCredentials: credentials);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        private SignInModel AuthenticateUser(SignInModel login)
        {
            SignInModel user = null;

            if (login.username == "Vraj123" && login.password == "Vraj123")
            {
                user = new SignInModel { username = "Vraj Shah" };
            }
            return user;
        }
        #endregion
    }
}
