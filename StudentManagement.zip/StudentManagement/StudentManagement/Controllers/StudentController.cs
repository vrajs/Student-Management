﻿using StudentManagement.Infrastructure;
using Microsoft.AspNetCore.Mvc;
using StudentManagement.Model;
using Microsoft.AspNetCore.Authorization;

namespace StudentManagement.Controllers
{
    /// <summary>
    /// Get the student list
    /// </summary>
    /// <seealso cref="Microsoft.AspNetCore.Mvc.ControllerBase" />
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        #region Variable Declaration

        private readonly IStudentService _studentservice;

        #endregion

        #region Constructor

        public StudentController(IStudentService studentservice)
        {
            _studentservice = studentservice;
        }
        #endregion

        #region API End Point

        /// <summary>
        /// Gets all students
        /// </summary>
        /// <returns>All Students list</returns>
        [HttpGet]
        public async Task<IActionResult> GetAllStudents()
        {
            try
            {
                var students = await _studentservice.GetStudents();
                if (students == null)
                {
                    return NotFound();
                }

                return Ok(students);
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }
        /// <summary>
        /// Gets all students
        /// </summary>
        /// <returns>All Students list</returns>
        [HttpGet("GetAllStudentsWithFilters")]
        public async Task<IActionResult> GetAllStudentsWithFilters(string? firstname, string? lastname, string? course)
        {
            try
            {
                var students = await _studentservice.GetStudentsByFilter(firstname,lastname,course);
                if (students == null)
                {
                    return NotFound();
                }

                return Ok(students);
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }


        /// <summary>
        /// Get Student Details by StudentId Parameter
        /// </summary>
        /// <param name="id">Accepts id parameter</param>
        /// <returns> Student Details</returns>
        [HttpGet("getStudentById")]
        public async Task<IActionResult> GetStudentById(int? id)
        {
            if (id == null)
            {
                return BadRequest();
            }

            try
            {
                var student = await _studentservice.GetStudentById(id);

                if (student == null)
                {
                    return NotFound();
                }

                return Ok(student);
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }

        /// <summary>
        /// Add Student in student table of StudentManagement database
        /// </summary>
        /// <param name="student">Accepts Student details</param>
        /// <returns>studentId</returns>
        [HttpPost]
        public async Task<IActionResult> AddStudent(StudentDto student)
        {
            student.CreatedOn = DateTime.Now;
            if (ModelState.IsValid)
            {
                try
                {
                    var studentid = await _studentservice.AddStudent(student);
                    if (studentid > 0)
                    {
                        return Ok(studentid);
                    }

                    return NotFound();
                }
                catch (Exception ex)
                {
                    return BadRequest(ex);
                }
            }

            return BadRequest();
        }

        /// <summary>
        /// Delete student
        /// </summary>
        /// <param name="id">Accepts studentId parameter</param>
        /// <returns>StudentId</returns>

        [HttpDelete]
        public async Task<IActionResult> DeleteStudent(int? id)
        {

            if (id == null)
            {
                return BadRequest();
            }

            int result = 0;
            try
            {
                result = await _studentservice.DeleteStudent(id);
                if (result == 0)
                {
                    return NotFound();
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
            return Ok();
        }

        /// <summary>
        /// Update Student details
        /// </summary>
        /// <param name="student">Accepts Student updated details</param>
        /// <returns></returns>
        [HttpPut]
        public async Task<IActionResult> UpdateStudent(StudentDto student)
        {
            var createdOnVal = await _studentservice.GetStudentById(student.StudentId);
            student.CreatedOn = createdOnVal.CreatedOn;
            student.UpdatedOn = DateTime.Now;
            if (ModelState.IsValid)
            {
                try
                {
                    var studentid = await _studentservice.UpdateStudent(student);

                    if (studentid > 0)
                    {
                        return Ok(studentid);
                    }
                    return NotFound();
                }
                catch (Exception ex)
                {
                    return BadRequest(ex);
                }
            }

            return BadRequest();
        }

        #endregion
    }
}
