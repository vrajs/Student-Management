﻿namespace StudentManagement.Helper
{
    public class SessionKeys
    {
        public const string Photo = "Photo";
    }
}
