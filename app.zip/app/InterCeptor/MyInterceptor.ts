import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpEvent, HttpResponse, HttpRequest, HttpHandler } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
export class MyInterceptor implements HttpInterceptor {
  TokenData: any;

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

    if (req.url == "http://localhost:4760/api/Employee/UploadFile") {
      const authReq = req.clone({

        headers: req.headers.set('Authorization', `Bearer ${this.TokenData}`).append('Access-Control-Allow-Origin', '*').append('Access-Control-Allow-Headers', '*')
      });
      return next.handle(authReq);
    }
    else {
      
      this.TokenData = sessionStorage.getItem('tokenValue')
      const authReq = req.clone({

        headers: req.headers.set('Authorization', `Bearer ${this.TokenData}`).append('Access-Control-Allow-Origin', '*').append('Access-Control-Allow-Headers', '*').set('content-type', 'application/json')
      });
      return next.handle(authReq);
    }
  }
}