export interface Employee {
    id: number,
    firstname: string,
    lastname: string,
    name: string,
    departmentId: number,
    location: string,
    lastName: string,
    gender: string,
    salary: number

}