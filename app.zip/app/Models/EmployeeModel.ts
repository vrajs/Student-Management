export interface Employee {
    id: number,
    firstname: string,
    name: string,
    departmentId: number,
    location: string,
    lastName: string,
    gender: string,
    salary: number,
    lastname: string,
    photo : any,
    wfh : boolean
}
export class Department {
    id: number;
    name: string;
}