export interface LoginI {
    username: string,
    password : string
}
