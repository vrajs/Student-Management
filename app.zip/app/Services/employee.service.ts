import { Injectable, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Department, Employee } from '../Models/EmployeeModel'
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  constructor(private http: HttpClient) 
  { }
  ngOnInit(): void {
  
  }

  get(): Observable<Employee[]> {
    
    return this.http.get<Employee[]>(`${environment.apiUrl}Employee`);
  }
  getDepartments(): Observable<Department[]> {
    
    return this.http.get<Department[]>(`${environment.apiUrl}Employee/GetDepartments`);
  }
  getById(id: number): Observable<Employee> {
    return this.http.get<Employee>(`${environment.apiUrl}Employee/getEmployeeById/?id=${id}`);
  }

  create(employee: Employee): Observable<Employee> {
    
    return this.http.post<Employee>(`${environment.apiUrl}Employee`,
    employee);
  }

  update(employee: Employee): Observable<Employee> {
    
    return this.http.put<Employee>(`${environment.apiUrl}Employee`,
    employee);
  }
  sendEmail(): Observable<boolean>{
    
    
    return this.http.get<boolean>(`${environment.apiUrl}Employee/SendMail`
    );
  }
  delete(id: string): Observable<number> {
    return this.http.delete<number>(`${environment.apiUrl}Employee/?id=${id}`);
  }
  upload(formdata: FormData): Observable<any> {
    
    return this.http.post<any>(`${environment.apiUrl}Employee/UploadFile`,
    formdata,{reportProgress:true,observe:'events'});
  }
}
