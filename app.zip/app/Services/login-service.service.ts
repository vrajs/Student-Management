import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { LoginI } from '../Models/loginModel';
import { Router } from '@angular/router';
import {CanActivate, } from '@angular/router'


@Injectable({
  providedIn: 'root'
})
export class LoginServiceService implements CanActivate {
public loginDone:boolean

  constructor(private http: HttpClient, private router: Router) { }

  canActivate(): boolean{
    
    if(sessionStorage.getItem('tokenValue') !=undefined){
        return true;
    }else{
      this.router.navigateByUrl('/login');
      return false;
    }
  }

  login(credential: LoginI): Observable<LoginI> {
    
    console.log(credential)
    
    return this.http.post<LoginI>(`${environment.apiUrl}Login`,
    credential);
  }
  
}
