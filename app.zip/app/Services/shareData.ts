import { Injectable } from '@angular/core';

@Injectable()
export class TransfereService {

    constructor() { }

    private studentId: number;

    SetStudentId(studentId: number) {
        
        this.studentId = studentId;
        
    }
    
    GetStudentId() {
        
        
        this.studentId;
        
        return this.studentId;
    }
}