import { Injectable, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Student } from '../Models/student-i'
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class StudentService implements OnInit{

  constructor(private http: HttpClient) 
  { }
  ngOnInit(): void {
  
  }

  get(): Observable<Student[]> {
    
    return this.http.get<Student[]>(`${environment.apiUrl}Student`);
  }

  getById(studentId: number): Observable<Student> {
    return this.http.get<Student>(`${environment.apiUrl}Student/getStudentById/?id=${studentId}`);
  }

  create(student: Student): Observable<Student> {
    console.log(student)
    return this.http.post<Student>(`${environment.apiUrl}Student`,
      student);
  }

  update(student: Student): Observable<Student> {
    student.studentId = student.id;
    return this.http.put<Student>(`${environment.apiUrl}Student`,
      student);
  }

  delete(studentid: string): Observable<number> {
    return this.http.delete<number>(`${environment.apiUrl}Student/?id=${studentid}`);
  }
}