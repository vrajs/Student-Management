import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CreateComponent } from './create/create.component'
import { ListComponent } from './list/list.component'
import { HomeComponent } from './home/home.component'
import { BlogComponent } from './blog/blog.component'
import { AboutComponent } from './about/about.component'
import { ErrorComponent } from './error/error.component'
import { LoginComponent } from './login/login.component'
import { LoginServiceService } from './Services/login-service.service';
import { EmployeeListComponent } from './employee-list/employee-list.component'
import {CreateEmployeeComponent} from './create-employee/create-employee.component'
import {ChartComponent} from './chart/chart.component'
import {ReportComponent} from './report/report.component'
import {CarouselComponent} from './carousel/carousel.component'

const routes: Routes = [
  { path: 'create', component: CreateComponent ,canActivate : [LoginServiceService]},
  { path: 'list', component: ListComponent ,canActivate : [LoginServiceService]},
  { path: 'List', component: ListComponent,canActivate : [LoginServiceService] },
  { path: 'listEmployee', component: EmployeeListComponent,canActivate : [LoginServiceService] },
  { path: '', component: LoginComponent },
  { path: 'home', component: HomeComponent ,canActivate : [LoginServiceService]},
  { path: 'update', component: CreateComponent ,canActivate : [LoginServiceService]},
  { path: 'blog', component: BlogComponent,canActivate : [LoginServiceService] },
  { path: 'about', component: AboutComponent ,canActivate : [LoginServiceService]},
  { path: 'employeeList', component: EmployeeListComponent ,canActivate : [LoginServiceService]},
  { path: 'createEmployee', component: CreateEmployeeComponent ,canActivate : [LoginServiceService]},
  { path: 'chart', component: ChartComponent ,canActivate : [LoginServiceService]},
  { path: 'report', component: ReportComponent ,canActivate : [LoginServiceService]},
  { path: 'carousel', component: CarouselComponent ,canActivate : [LoginServiceService]},
  { path: 'login', component: LoginComponent },
  { path: '**', component: ErrorComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
