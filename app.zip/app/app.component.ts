import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'StudentManagement';
  show :boolean
  
  ngOnInit(): void {
    this.show=false;
  }
  isLogin = false;

  constructor(private router: Router) {
    
    if(sessionStorage.getItem('tokenValue') !=undefined){
      this.isLogin=true;
    }
   
  }

}
