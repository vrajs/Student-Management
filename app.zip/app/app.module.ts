import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';  
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
// import { RouterModule, Routes } from '@angular/router';

import {AgGridModule} from 'ag-grid-angular';
import { MyInterceptor } from './InterCeptor/MyInterceptor';
// import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ListComponent } from './list/list.component';

import { CreateComponent } from './create/create.component';
import { HomeComponent } from './home/home.component';
import {StudentService} from './Services/student-service.service'
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http'; 

import { BlogComponent } from './blog/blog.component';
import { AboutComponent } from './about/about.component';
import { ErrorComponent } from './error/error.component';
import { LoginComponent } from './login/login.component';
import {TransfereService} from './Services/shareData';
import { HeaderComponent } from './header/header.component'
import { LoginServiceService } from './Services/login-service.service';
import {  ToastrModule  } from 'ngx-toastr';  
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { CreateEmployeeComponent } from './create-employee/create-employee.component';
import { ChartComponent } from './chart/chart.component';

import { 
	IgxCategoryChartModule,
	IgxLegendModule
 } from "igniteui-angular-charts";
import { ReportComponent } from './report/report.component';
import { CarouselComponent } from './carousel/carousel.component';
import { SignaturePadModule } from 'angular2-signaturepad';

@NgModule({
  declarations: [
    AppComponent,
    ListComponent,
    CreateComponent,
    HomeComponent,
    BlogComponent,
    AboutComponent,
    ErrorComponent,
    LoginComponent,
    HeaderComponent,
    EmployeeListComponent,
    CreateEmployeeComponent,
    ChartComponent,
    ReportComponent,
    CarouselComponent,
  ],
  imports: [
    BrowserModule,  
    FormsModule,  
    ReactiveFormsModule,    
    HttpClientModule,  
    BrowserAnimationsModule,   
    AppRoutingModule,
    AgGridModule,
    IgxCategoryChartModule,
    SignaturePadModule ,
	IgxLegendModule,
    ToastrModule.forRoot({
      positionClass :'toast-bottom-right'
    })
  ],
  
  providers: [StudentService,HttpClientModule,TransfereService,ToastrModule,AgGridModule,LoginServiceService,{ provide: HTTP_INTERCEPTORS, useClass: MyInterceptor, multi: true }],
  bootstrap: [AppComponent]
})
export class AppModule { }
