import { Component, OnInit, EventEmitter, Output, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Department, Employee } from '../Models/EmployeeModel'
import { EmployeeService } from '../Services/employee.service'
import { Router, ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { Injector } from '@angular/core';
import { HttpClient, HttpEventType, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { SignaturePad } from 'angular2-signaturepad';

@Component({
  selector: 'app-create-employee',
  templateUrl: './create-employee.component.html',
  styleUrls: ['./create-employee.component.css']
})
export class CreateEmployeeComponent implements OnInit {
  public progress: number;
  public message: string;
  @Output() public onUploadFinished = new EventEmitter();
  imageSrc: string;

  signatureImg: string;
  @ViewChild(SignaturePad) signaturePad: SignaturePad;
  allDepartments: Observable<Department[]>;
  isAddMode: boolean;
  employeeIdUpdate: number = 0;
  employeeID: number;

  constructor(injector: Injector, private employeeService: EmployeeService, private router: Router, private route: ActivatedRoute) {

    this.route.queryParams.subscribe(params => {
      this.employeeID = params['id'];

    });
  }
  signaturePadOptions: Object = { 
    'minWidth': 2,
    'canvasWidth': 700,
    'canvasHeight': 100
  };
  ngAfterViewInit() {
    // this.signaturePad is now available
    this.signaturePad.set('minWidth', 2); 
    this.signaturePad.clear(); 
  }

  drawComplete() {
    console.log(this.signaturePad.toDataURL());
  }

  drawStart() {
    console.log('begin drawing');
  }

  clearSignature() {
    this.signaturePad.clear();
  }

  savePad() {
    const base64Data = this.signaturePad.toDataURL();
    this.signatureImg = base64Data;
  }
  
  onFileChange(event:any) {
    const reader = new FileReader();
    
    if(event.target.files && event.target.files.length) {
      const [file] = event.target.files;
      reader.readAsDataURL(file);
    
      reader.onload = () => {
   
        this.imageSrc = reader.result as string;
     
        this.employeeForm.patchValue({
          fileSource: reader.result
        });
   
      };
   
    }
  }

  uploadFile = (files: any) => {
    
    if (files.length === 0) {
      return;
    }
    let fileToUpload = <File>files[0];
    const formData = new FormData();
    formData.append('file', fileToUpload, fileToUpload.name);
    this.employeeService.upload(formData).subscribe({
      next: (event) => {
        
        if (event.type === HttpEventType.UploadProgress)
          this.progress = Math.round(100 * event.loaded);
        else if (event.type === HttpEventType.Response) {
          this.message = 'Upload success.';
          this.onUploadFinished.emit(event.body);
        }
      },
      error: (err: HttpErrorResponse) => console.log(err)
    });;
    alert("File Uploaded Successfully")
  }
  employeeForm = new FormGroup({
    firstname: new FormControl('', [Validators.required]),
    departmentId: new FormControl('', [Validators.required]),
    lastname: new FormControl('', [Validators.required]),
    gender: new FormControl('', [Validators.required]),
    salary: new FormControl('', [Validators.required]),
    wfh: new FormControl(''),
  })
  get firstname() {
    return this.employeeForm.get('firstname')
  }
  get departmentId() {
    return this.employeeForm.get('departmentId')
  }
  get lastname() {
    return this.employeeForm.get('lastname')
  }
  get gender() {
    return this.employeeForm.get('gender')
  }
  get salary() {
    return this.employeeForm.get('salary')
  }
  get wfh() {
    return this.employeeForm.get('wfh')
  }

  ngOnInit() {
    
    this.SetDepartmentsDropDown();
    if (this.employeeID == undefined) {
      this.isAddMode = true;
    }
    else {
      this.isAddMode = false;
      this.setFormValues(this.employeeID)
    }
  }
  SetDepartmentsDropDown() {
    
    this.allDepartments = this.employeeService.getDepartments();
    console.log(this.allDepartments);
  }
  setFormValues(employeeIdPass: number) {
    
    this.employeeService.getById(employeeIdPass).subscribe((employee: any) => {
      this.employeeIdUpdate = employeeIdPass;

      this.employeeForm.controls['firstname'].setValue(employee.firstname);
      this.employeeForm.controls['lastname'].setValue(employee.lastName);
      this.employeeForm.controls['gender'].setValue(employee.gender);
      this.employeeForm.controls['salary'].setValue(employee.salary);
      this.employeeForm.controls['departmentId'].setValue(employee.departmentId);
      this.employeeForm.controls['wfh'].setValue(employee.wfh);
      this.isAddMode = false;
    }, (err) => {
      alert("Something Went Wrong")
    });

  }
  createEmployee(employee: Employee) {
    
    this.employeeService.create(employee).subscribe(
      () => {
        alert("SuccessFully Added");
        this.router.navigateByUrl('/listEmployee');
      }, (err) => {
        alert("Something Went Wrong")
      }
    );
  }

  onSave() {
    
    const employee = this.employeeForm.value;
    if(employee.wfh == ""){
      employee.wfh = false;
    }
    if (this.isAddMode) {
      this.createEmployee(employee);
    }
    else {
      this.UpdateEmployee(employee);
    }
  }
  UpdateEmployee(employee: Employee) {
    
    
    employee.id = this.employeeIdUpdate;
    this.employeeService.update(employee).subscribe(() => {
      alert("SuccessFully Updated")

      this.router.navigateByUrl('/listEmployee');

    }, (err) => {
      alert("Something Went Wrong")
    });
  }

}
