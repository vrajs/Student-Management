import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Student } from '../Models/student-i'
import { StudentService } from '../Services/student-service.service'
import { Router, ActivatedRoute } from '@angular/router';
import {TransfereService} from '../Services/shareData'

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {

  isAddMode: boolean;
  studentIdUpdate: number = 0;
  studentID: number;

  constructor(private studentservice: StudentService, private router: Router, private route: ActivatedRoute,private transfereService:TransfereService) {

    this.route.queryParams.subscribe(params => {
      
      this.studentID = transfereService.GetStudentId();
        
    });
  }
  studentForm = new FormGroup({
    firstname: new FormControl('', [Validators.required]),
    lastname: new FormControl('', [Validators.required]),
    email: new FormControl('', [Validators.required, Validators.email]),
    course: new FormControl('', [Validators.required]),
  })
  get firstname() {
    return this.studentForm.get('firstname')
  }
  get lastname() {
    return this.studentForm.get('lastname')
  }
  get email() {
    return this.studentForm.get('email')
  }
  get course() {
    return this.studentForm.get('course')
  }
  ngOnInit() {
    
    if (this.studentID == undefined) {
      this.isAddMode = true;
    }
    else {
      this.isAddMode = false;
      this.setFormValues(this.studentID)
    }
  }
  setFormValues(studentIdPass: number) {

    this.studentservice.getById(studentIdPass).subscribe((student2: any) => {
      this.studentIdUpdate = studentIdPass;
    
      this.studentForm.controls['firstname'].setValue(student2.firstName);
      this.studentForm.controls['lastname'].setValue(student2.lastName);
      this.studentForm.controls['email'].setValue(student2.email);
      this.studentForm.controls['course'].setValue(student2.course);
      this.isAddMode = false;
    }, (err) => {
      alert("Something Went Wrong")
    });

  }
  createStudent(student: Student) {
    this.studentservice.create(student).subscribe(
      () => {
        alert("SuccessFully Added")
        this.router.navigateByUrl('/list');
      }, (err) => {
        alert("Something Went Wrong")
      }
    );
  }
  
  onSave() {
    const student = this.studentForm.value;
    if(this.isAddMode){
      this.createStudent(student);
    }
    else{
      this.UpdateStudent();
    }
  }
  UpdateStudent() {
    const student = this.studentForm.value;
    student.id = this.studentIdUpdate;
    this.studentservice.update(student).subscribe(() => {
     alert("SuccessFully Updated")
      this.router.navigateByUrl('/list');
      
    }, (err) => {
      alert("Something Went Wrong")
    });
  }
}
