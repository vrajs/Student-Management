import { Component, OnInit } from '@angular/core';

import { EmployeeService } from '../Services/employee.service'
import { Router } from '@angular/router';
import { ColDef, GridApi, ColumnApi, GridOptions } from 'ag-grid-community';
// import { AgGridModule, AgGridAngular } from 'ag-grid-angular';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Employee } from '../Models/EmployeeModel';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {
  employees: any = [];

  totalNoOfRows: number;
  token: any;
  dataT: any;

  private api: GridApi;
  private columnApi: ColumnApi;
  public gridOptions: GridOptions = {};

  colDefs: ColDef[] = [
    { field: 'id', hide: true },
    
    { field: 'departmentId', hide: true },
    { field: 'firstname', sortable: true, filter: true, checkboxSelection: true },
    { field: 'lastName', sortable: true, filter: true },
    { field: 'name', sortable: true, filter: true, headerName: "Department" },
    { field: 'location', sortable: true, filter: true },
    { field: 'gender', sortable: true, filter: true },
    { field: 'salary', sortable: true, filter: true },
  ];

  rowData$: Observable<Employee[]>;

  constructor(private employeeService: EmployeeService, private router: Router) {

    this.gridOptions.pagination = true;
    this.gridOptions.paginationPageSize = 7;
  }
  ngOnInit() {
    this.employeeService.sendEmail();
    this.loademployees();
  }
  onGridReady(params: { api: GridApi; columnApi: ColumnApi; }): void {
    this.api = params.api;
    this.columnApi = params.columnApi;
    this.api.sizeColumnsToFit();
  }
  loademployees() {
    
    this.rowData$ = this.employeeService.get()
    
    console.log(this.rowData$)
  }
  navigateToEdit() {
    
    const d = this.api.getEditingCells();
    if (this.api.getSelectedRows().length == 0) {
      
      return;
    }
    var row = this.api.getSelectedRows();

    this.router.navigateByUrl('/createEmployee?id=' + row[0].id);
  }

  deleteEmployee() {
    
    var selectedRows = this.api.getSelectedRows();
    if (selectedRows.length == 0) {
     
      return;
    }
    if (confirm("Are you sure you want to delete this ?")) {
      this.employeeService.delete(selectedRows[0].id).subscribe(() => {
        this.loademployees();
        alert("Successfully Deleted")
      }, (err) => {
        alert("Something Went Wrong")
      });
    }
  }

}
