import { Component, OnInit } from '@angular/core';
import { StudentService } from '../Services/student-service.service'
import { Router } from '@angular/router';
import { ColDef, GridApi, ColumnApi, GridOptions } from 'ag-grid-community';
// import { AgGridModule, AgGridAngular } from 'ag-grid-angular';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Student } from '../Models/student-i';
import { ToastrService } from 'ngx-toastr';
import {TransfereService} from '../Services/shareData'

@Component({
  selector: 'app-list-test',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {
  students: any = [];

  totalNoOfRows: number;
  token: any;
  dataT: any;

  private api: GridApi;
  private columnApi: ColumnApi;
  public gridOptions: GridOptions = {};

  colDefs: ColDef[] = [
    { field: 'studentId', hide: true },
    { field: 'firstName', sortable: true, filter: true, checkboxSelection: true },
    { field: 'lastName', sortable: true, filter: true },
    { field: 'email', sortable: true, filter: true },
    { field: 'course', sortable: true, filter: true },
  ];

  rowData$: Observable<Student[]>;

  constructor(private studentservice: StudentService, private router: Router, private http: HttpClient, private toastr: ToastrService,private transfereService:TransfereService) {
    
    this.gridOptions.pagination = true;
    this.gridOptions.paginationPageSize = 7;
  }

  ngOnInit() {
    
    this.loadStudents();
  }
  onGridReady(params: { api: GridApi; columnApi: ColumnApi; }): void {
    this.api = params.api;
    this.columnApi = params.columnApi;
    this.api.sizeColumnsToFit();
  }
  loadStudents() {

    this.rowData$ = this.studentservice.get()
    console.log(this.rowData$)
  }

  navigateToEdit() {

    const d = this.api.getEditingCells();
    if (this.api.getSelectedRows().length == 0) {
      alert("Please Select Student")
      return;
    }
    
    var row = this.api.getSelectedRows();
    this.transfereService.SetStudentId(row[0].studentId);
    this.router.navigateByUrl('/update');
  }

  deleteStudent() {

    var selectedRows = this.api.getSelectedRows();
    if (selectedRows.length == 0) {
      alert("Please Select Student")
      return;
    }
    if (confirm("Are you sure you want to delete this ?")) {
      this.studentservice.delete(selectedRows[0].studentId).subscribe(() => {
        this.loadStudents();
        alert("Successfully Deleted")
      }, (err) => {
        alert("Something Went Wrong")
      });
    }
  }

}
