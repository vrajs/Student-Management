import { Component, NgZone, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

import { Router } from '@angular/router';

import { LoginServiceService } from '../Services/login-service.service'

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  token: any;
  redirectToList: boolean;
  isLogin = false;

  constructor(private loginService: LoginServiceService, private router: Router, private ngZone: NgZone) {
    this.redirectToList = false;
  }
  ngOnInit(): void {

  }

  loginForm = new FormGroup({
    username: new FormControl('', [Validators.required]),
    password: new FormControl('', [Validators.required]),

  })
  get username() {
    return this.loginForm.get('username')
  }
  get password() {
    return this.loginForm.get('password')
  }

  onSignIn() {
    
    const student = this.loginForm.value;

    this.loginService.login(student).subscribe((respose) => {

      this.token = respose;
      this.redirectToList = true;
      
      sessionStorage.setItem('tokenValue', this.token.token)
      this.isLogin = true;
      this.lastAction(Date.now());
      this.check();
      this.initListener();
      this.initInterval();


      this.router.navigateByUrl('/list');

    }, (err) => {
      alert("Invalid email or password")
    });

  }
  getLastAction(): any {
    
    return sessionStorage.getItem('lastAction');
  }

  /**
   * set last action
   * @param value
   */
  lastAction(value: number) {
    
    sessionStorage.setItem('lastAction', JSON.stringify(value))
  }

  /**
   * start event listener
   */
  initListener() {
    this.ngZone.runOutsideAngular(() => {
      document.body.addEventListener('click', () => this.reset());
    });
  }

  /**
   * time interval
   */
  initInterval() {
    
    this.ngZone.runOutsideAngular(() => {
      setInterval(() => {
        this.check();
      }, 1000);
    })
  }

  /**
   * reset timer
   */
  reset() {
    this.lastAction(Date.now());
  }

  /**
   * check timer
   */
  check() {
    
    const now = Date.now();
    const timeLeft = parseInt(this.getLastAction()) + (5) * 60 * 1000;
    const diff = timeLeft - now;
    const isTimeout = diff < 0;
    //this.isLoggedIn.subscribe(event => this.isLogin = event);
    this.ngZone.run(() => {
      if (isTimeout && this.isLogin) {
        sessionStorage.removeItem('tokenValue');
        sessionStorage.removeItem('lastAction');
        setTimeout(() => {
          console.log("Your Session Expired due to longer Inactivity, Login Again To Continue");
        }, 1000);
        this.router.navigateByUrl('/login');
      }
    });
  }

  /**
   *check if a user is logged in
   */

}
