import { HttpClient } from '@angular/common/http';
import { Component, Input, OnInit, Inject } from '@angular/core';
import { Router } from '@angular/router';
import jsPDF from 'jspdf'
import autoTable from 'jspdf-autotable'
import { EmployeeService } from '../Services/employee.service';

@Component({
  selector: 'app-report',
  templateUrl: './report.component.html',
  styleUrls: ['./report.component.css']
})
export class ReportComponent implements OnInit {

  data: any;
    jsPDF: any;

  constructor(private employeeService: EmployeeService, private router: Router, private http: HttpClient) { }

  ngOnInit() {

    this.loadEmployeesData();
  }

  loadEmployeesData() {

    this.data = this.employeeService.get().subscribe((result) => {
      this.data = result;
    });
  }

  DownloadReport() {
    
    let row: any[] = []
    let rowD: any[] = []
    let col = [[ 'Firstname', 'LastName', 'Department', 'Location', 'Gender', 'Salary']]; // initialization for headers
    let title = "Employee Report" // title of report
    for (let a = 0; a < this.data.length; a++) {
      // row.push(this.data[a].id)
      row.push(this.data[a].firstname)
      row.push(this.data[a].lastName)
      row.push(this.data[a].name)
      // row.push(this.data[a].departmentId)
      row.push(this.data[a].location)
      
      row.push(this.data[a].gender)
      row.push(this.data[a].salary)
      rowD.push(row);
      row = [];
    }
    // this.getReport(col, rowD, title);
    // const totalPagesExp = "{total_pages_count_string}";
    let pdf = new jsPDF('l', 'pt', 'legal');
    pdf.setTextColor(51, 156, 255);
    pdf.text("Employees Report", 450, 40);
    // pdf.text("Email:", 450, 60); // 450 here is x-axis and 80 is y-axis
    // pdf.text("Phone:", 450, 80); // 450 here is x-axis and 80 is y-axis
    // pdf.text("" + title, 435, 100);  //
    pdf.setLineWidth(1.5);
    pdf.line(5, 107, 995, 107)
  //   var pageContent = function (data2: { pageCount: string; settings: { margin: { left: number; }; }; }) {
  //     // HEADER
     
  //     // FOOTER
  //     var str = "Page " + data2.pageCount;
  //     // Total page number plugin only available in jspdf v1.0+
  //     if (typeof pdf.putTotalPages === 'function') {
  //         str = str + " of " + totalPagesExp;
  //     }
  //     pdf.setFontSize(10);
  //     var pageHeight = pdf.internal.pageSize.height || pdf.internal.pageSize.getHeight();
  //     pdf.text(str, data2.settings.margin.left, pageHeight - 10); // showing current page number
  // };
  autoTable(pdf, {
    head: col,
    body: rowD,
    didDrawCell: (data) => { },
});

  //for adding total number of pages // i.e 10 etc
  // if (typeof pdf.putTotalPages === 'function') {
  //     pdf.putTotalPages(totalPagesExp);
  // }

  pdf.save(title + '.pdf');

  }

  getReport(col: any[], rowD: any[], title: any) {
    
    }
}
